/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from 'react';
import { motion, useScroll, useSpring, AnimatePresence } from 'motion/react';
import { 
  ArrowUpRight, 
  ShoppingBasket, 
  CheckCircle2, 
  Mail, 
  Instagram, 
  Twitter, 
  Github,
  Figma,
  Layout,
  Palette,
  Layers,
  Monitor,
  Smartphone,
  Zap
} from 'lucide-react';

// Custom Cursor Component
const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [trailPosition, setTrailPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      // Slight delay for the trail
      setTimeout(() => {
        setTrailPosition({ x: e.clientX, y: e.clientY });
      }, 50);
    };
    window.addEventListener('mousemove', onMouseMove);
    return () => window.removeEventListener('mousemove', onMouseMove);
  }, []);

  return (
    <>
      <div 
        className="cursor-dot" 
        style={{ left: `${position.x}px`, top: `${position.y}px`, transform: 'translate(-50%, -50%)' }} 
      />
      <div 
        className="cursor-trail" 
        style={{ left: `${trailPosition.x}px`, top: `${trailPosition.y}px`, transform: 'translate(-50%, -50%)' }} 
      />
    </>
  );
};

// Magnetic Button Wrapper
const MagneticButton = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => {
  const btnRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!btnRef.current) return;
    const { left, top, width, height } = btnRef.current.getBoundingClientRect();
    const x = e.clientX - (left + width / 2);
    const y = e.clientY - (top + height / 2);
    
    btnRef.current.style.transform = `translate(${x * 0.3}px, ${y * 0.3}px)`;
  };

  const handleMouseLeave = () => {
    if (!btnRef.current) return;
    btnRef.current.style.transform = `translate(0px, 0px)`;
  };

  return (
    <div 
      ref={btnRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`magnetic-btn ${className}`}
    >
      {children}
    </div>
  );
};

const ToolIcon = ({ icon: Icon, label }: { icon: any, label: string }) => (
  <div className="flex flex-col items-center gap-2 px-6 py-4 glass rounded-2xl opacity-40 hover:opacity-100 transition-opacity cursor-default min-w-[120px]">
    <Icon size={24} className="text-white" />
    <span className="text-[10px] uppercase tracking-widest font-medium">{label}</span>
  </div>
);

interface ServiceCardProps {
  title: string;
  image: string;
  index: number;
  key?: React.Key;
}

const ServiceCard = ({ title, image, index }: ServiceCardProps) => (
  <motion.div 
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.1, duration: 0.8 }}
    className="service-card group aspect-[4/5] rounded-3xl overflow-hidden bg-zinc-900 border border-white/5"
  >
    <img 
      src={image} 
      alt={title} 
      className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:scale-110 transition-transform duration-700"
      referrerPolicy="no-referrer"
    />
    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
    
    <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end">
      <h3 className="text-xl font-bold tracking-tight max-w-[150px] leading-tight uppercase">{title}</h3>
      <button className="w-12 h-12 rounded-full bg-emerald-accent flex items-center justify-center text-black shadow-[0_0_20px_rgba(0,255,136,0.3)] hover:scale-110 transition-transform">
        <ArrowUpRight size={24} />
      </button>
    </div>
  </motion.div>
);

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  const services = [
    { title: "Brand Identity", image: "https://picsum.photos/seed/brand/800/1000" },
    { title: "Product Design", image: "https://picsum.photos/seed/product/800/1000" },
    { title: "Visual Strategy", image: "https://picsum.photos/seed/strategy/800/1000" },
    { title: "UI/UX Interface", image: "https://picsum.photos/seed/uiux/800/1000" },
    { title: "Motion Graphics", image: "https://picsum.photos/seed/motion/800/1000" },
    { title: "3D Rendering", image: "https://picsum.photos/seed/3d/800/1000" },
  ];

  return (
    <div className="min-h-screen font-sans selection:bg-emerald-accent selection:text-black">
      <CustomCursor />
      
      {/* Scroll Progress Bar */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-emerald-accent z-[100] origin-left"
        style={{ scaleX }}
      />

      {/* Header Navigation */}
      <header className="fixed top-8 left-1/2 -translate-x-1/2 z-50 flex gap-4">
        <MagneticButton>
          <button className="glass px-6 py-3 rounded-full flex items-center gap-2 text-sm font-medium hover:bg-white/10 transition-colors">
            See my work <ArrowUpRight size={16} className="text-emerald-accent" />
          </button>
        </MagneticButton>
        <MagneticButton>
          <button className="glass px-6 py-3 rounded-full flex items-center gap-2 text-sm font-medium hover:bg-white/10 transition-colors">
            My catalog <ShoppingBasket size={16} className="text-emerald-accent" />
          </button>
        </MagneticButton>
        <MagneticButton>
          <button className="glass px-6 py-3 rounded-full flex items-center gap-2 text-sm font-medium hover:bg-white/10 transition-colors">
            Book a service <CheckCircle2 size={16} className="text-emerald-accent" />
          </button>
        </MagneticButton>
      </header>

      <main>
        {/* Hero Section */}
        <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 px-6 overflow-hidden">
          {/* Background Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-accent/5 blur-[120px] rounded-full pointer-events-none" />
          
          <div className="container mx-auto grid grid-cols-1 lg:grid-cols-3 items-center gap-12 relative z-10">
            {/* Left Bio */}
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="hidden lg:block space-y-4"
            >
              <p className="text-emerald-accent font-mono text-xs tracking-[0.3em] uppercase">Based in Paris</p>
              <h2 className="text-2xl font-light leading-tight">
                Graphic/Product & <br />
                <span className="font-bold">Brand Designer</span>
              </h2>
            </motion.div>

            {/* Center Avatar & Title */}
            <div className="flex flex-col items-center">
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                className="relative w-64 h-64 md:w-80 md:h-80 mb-8"
              >
                <div className="absolute inset-0 bg-emerald-accent/20 blur-3xl rounded-full" />
                <img 
                  src="https://picsum.photos/seed/avatar/600/600" 
                  alt="Avatar" 
                  className="w-full h-full object-cover rounded-full border-2 border-white/10 relative z-10"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.5 }}
                className="text-6xl md:text-8xl lg:text-9xl font-black tracking-tighter text-center text-gradient uppercase"
              >
                RE NCE <br />
                <span className="text-emerald-accent">IVann</span>
              </motion.h1>
            </div>

            {/* Right Bio */}
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="space-y-6 max-w-xs mx-auto lg:mx-0"
            >
              <p className="text-zinc-400 text-sm leading-relaxed">
                Crafting digital experiences that blend futuristic aesthetics with functional precision. Specializing in high-end brand identities and product interfaces.
              </p>
              <div className="flex gap-4">
                <div className="h-px w-12 bg-emerald-accent mt-3" />
                <span className="text-xs font-mono uppercase tracking-widest text-zinc-500">Scroll to explore</span>
              </div>
            </motion.div>
          </div>

          {/* Tools Bar */}
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="w-full mt-24 overflow-hidden"
          >
            <div className="flex gap-4 no-scrollbar overflow-x-auto pb-8 px-6 justify-center">
              <ToolIcon icon={Figma} label="Figma" />
              <ToolIcon icon={Palette} label="Adobe AI" />
              <ToolIcon icon={Layers} label="Photoshop" />
              <ToolIcon icon={Layout} label="Canva" />
              <ToolIcon icon={Monitor} label="Webflow" />
              <ToolIcon icon={Smartphone} label="Framer" />
              <ToolIcon icon={Zap} label="Asana" />
            </div>
          </motion.div>
        </section>

        {/* Services Section */}
        <section className="py-32 px-6 bg-zinc-950">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
              <div className="space-y-4">
                <p className="text-emerald-accent font-mono text-xs tracking-[0.3em] uppercase">Capabilities</p>
                <h2 className="text-4xl md:text-6xl font-bold tracking-tight uppercase">Services <br />I Provide</h2>
              </div>
              <p className="text-zinc-500 max-w-sm text-sm">
                From conceptualization to final execution, I provide end-to-end design solutions that elevate your brand to the next level.
              </p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
              {services.map((service, index) => (
                <ServiceCard key={index} index={index} title={service.title} image={service.image} />
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <footer className="py-32 px-6 border-t border-white/5">
          <div className="container mx-auto text-center space-y-16">
            <div className="space-y-6">
              <p className="text-emerald-accent font-mono text-xs tracking-[0.3em] uppercase">Let's connect</p>
              <h2 className="text-5xl md:text-8xl font-black tracking-tighter uppercase">Contact Me</h2>
              <p className="text-zinc-400 text-lg max-w-xl mx-auto">
                Have a project in mind or just want to say hi? Feel free to reach out through any of the platforms below.
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-6">
              <MagneticButton>
                <a href="mailto:hello@ivann.design" className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-emerald-accent hover:text-black transition-all duration-500">
                  <Mail size={24} />
                </a>
              </MagneticButton>
              <MagneticButton>
                <a href="#" className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-emerald-accent hover:text-black transition-all duration-500">
                  <Instagram size={24} />
                </a>
              </MagneticButton>
              <MagneticButton>
                <a href="#" className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-emerald-accent hover:text-black transition-all duration-500">
                  <Twitter size={24} />
                </a>
              </MagneticButton>
              <MagneticButton>
                <a href="#" className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-emerald-accent hover:text-black transition-all duration-500">
                  <Github size={24} />
                </a>
              </MagneticButton>
              <MagneticButton>
                <a href="#" className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-emerald-accent hover:text-black transition-all duration-500">
                  <CheckCircle2 size={24} />
                </a>
              </MagneticButton>
            </div>

            <div className="pt-20 flex flex-col md:flex-row justify-between items-center gap-8 border-t border-white/5 text-zinc-600 text-xs font-mono uppercase tracking-widest">
              <p>© 2024 IVann Design. All rights reserved.</p>
              <div className="flex gap-8">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
